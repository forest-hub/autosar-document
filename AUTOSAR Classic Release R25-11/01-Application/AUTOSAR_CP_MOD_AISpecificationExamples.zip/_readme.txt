Document Title:                 Application Interface Examples
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 638
Document Status:                published
Part of AUTOSAR Standard:       Classic Platform
Part of Standard Release:       R25-11
Date:                           2025-11-27



This archive contains the examples that are used to discuss the Application
Interface model elements defined within the AUTOSAR standardization work.
In particular, it contains example Software Compositions that show the context
and/or application of the Port Prototype Blueprints defined in the AUTOSAR Standard.

This archive also contains examples of some software design pattern implementations.
For example, you'll find a few variants of the sensor-actuator pattern (S/A pattern) implementations.


The Application Interface Examples requires the xml namespace definition file xml.xsd as xsd:import. 
For xml.xsd the W3C license applies, which can be found on
https://www.w3.org/Consortium/Legal/2015/copyright-software-and-document:

    License

    By obtaining and/or copying this work, you (the licensee) agree that you have read, understood, and will comply with the following terms and conditions.

    Permission to copy, modify, and distribute this work, with or without modification, for any purpose and without fee or royalty is hereby granted, provided that you include the following on ALL copies of the work or portions thereof, including modifications:

        The full text of this NOTICE in a location viewable to users of the redistributed or derivative work.
        Any pre-existing intellectual property disclaimers, notices, or terms and conditions. If none exist, the W3C Software and Document Short Notice should be included.
        Notice of any changes or modifications, through a copyright statement on the new code or document such as "This software or document includes material copied from or derived from [title and URI of the W3C document]. Copyright © [YEAR] W3C® (MIT, ERCIM, Keio, Beihang)." 

    Disclaimers

    THIS WORK IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENT WILL NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.

    COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF ANY USE OF THE SOFTWARE OR DOCUMENT.

    The name and trademarks of copyright holders may NOT be used in advertising or publicity pertaining to the work without specific, written prior permission. Title to copyright in this work will at all times remain with copyright holders.



The life cycle information AUTOSAR_MOD_*_LifeCycle.arxml needs always 
to be considered, as it is the only source to know whether a model element is valid and part 
of the release.

The folder comprises the following files:
		
	AI specification examples ARXML files
	============================
	AUTOSAR_MOD_AISpecificationExamples.arxml
	AUTOSAR_MOD_AISpecificationExamples_LifeCycle.arxml
	AUTOSAR_MOD_SwDesignPatternExamples.arxml
	AUTOSAR_MOD_SwDesignPatternExamples_LifeCycle.arxml
	
	AUTOSAR catalog files
	=====================
	AUTOSAR_CC_AISpecificationExamples.xml (AUTOSAR catalog file - explanation see below)
	catalog_V3_0_0.ml.xsd (XML schema file for AUTOSAR catalog file)


Additional external files are required to resolve all references within this
file: AUTOSAR_MOD_AISpecification.zip, AUTOSAR_FO_MOD_GeneralDefinitions.zip


How to use:
1) Obtain AUTOSAR_CP_MOD_AISpecificationExamples.zip, AUTOSAR_CP_MOD_AISpecification.zip, AUTOSAR_FO_MOD_GeneralDefinitions.zip
   and store in _one_ common folder
2) Unzip all three files, using the "unzip to <filename>" option, resulting in the following folder structure:
   ./
   -> AUTOSAR_CP_MOD_AISpecificationExamples/
   -> AUTOSAR_CP_MOD_AISpecification/
   -> AUTOSAR_FO_MOD_GeneralDefinitions/
3) The catalog file will support AUTOSAR tools to resolve the references. If you want to use a different file layout,
   you have to adapt the catalog file accordingly.
